from authentication.app import app as _app

app = _app


