from shortener.app import app as _app

app = _app
