# -*- coding: utf-8 -*-

# """Top-level package for python url shortener."""
from shortener import views as _views

__author__ = """group03"""
__email__ = "group03@noreply.com"
__version__ = "0.1.0"

views = _views
