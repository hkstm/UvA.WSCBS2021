# -*- coding: utf-8 -*-

from authentication import views as _views

__author__ = """group03"""
__email__ = "group03@noreply.com"
__version__ = "0.1.0"

views = _views
